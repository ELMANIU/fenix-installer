package com.fenixtv.installer

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.fenixtv.installer.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import okhttp3.OkHttpClient
import okhttp3.Request
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.File
import java.security.MessageDigest
import java.security.Security
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var token: String = ""
    private var baseUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        try {
            Security.removeProvider(BouncyCastleProvider.PROVIDER_NAME)
            Security.insertProviderAt(BouncyCastleProvider(), 1)
        } catch (_: Exception) { }

        val prefs = getSharedPreferences("fenix", MODE_PRIVATE)
        b.tvIp.setText(prefs.getString("tvIp", ""))
        baseUrl = prefs.getString("baseUrl", "") ?: ""
        readInstallIntent(intent)

        b.installButton.setOnClickListener { startInstall() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readInstallIntent(intent)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun readInstallIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        if (uri.scheme != "fenixtvinstaller" || uri.host != "install") return
        token = uri.getQueryParameter("token") ?: ""
        val incomingBase = (uri.getQueryParameter("base") ?: "").trimEnd('/')
        if (incomingBase.isNotBlank()) {
            baseUrl = incomingBase
            getSharedPreferences("fenix", MODE_PRIVATE)
                .edit().putString("baseUrl", baseUrl).apply()
        }
        if (token.isNotBlank()) status("✅ Enlace de instalación recibido. Escribe IP y passphrase de tu LG.")
    }

    private fun startInstall() {
        val ip = b.tvIp.text.toString().trim()
        val pass = b.passphrase.text.toString().trim()
        if (ip.isBlank() || pass.isBlank() || baseUrl.isBlank() || token.isBlank()) {
            status("Abre FÉNIX Installer desde el botón de Telegram y completa IP + passphrase.")
            return
        }

        getSharedPreferences("fenix", MODE_PRIVATE)
            .edit().putString("tvIp", ip).putString("baseUrl", baseUrl).apply()

        b.progress.visibility = View.VISIBLE
        b.installButton.isEnabled = false

        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    statusUi("1/6 Consultando última versión…")
                    val meta = resolveLatest()
                    statusUi("2/6 Descargando FÉNIX TV ${meta.version}…")
                    val ipk = download(meta.downloadUrl, meta.fileName)
                    if (!sha256(ipk).equals(meta.sha256, true)) {
                        ipk.delete()
                        error("La verificación SHA-256 falló")
                    }

                    statusUi("3/6 Obteniendo llave de Developer Mode…")
                    val key = fetchTvKey(ip)

                    statusUi("4/6 Conectando con la LG…")
                    installOverSsh(ip, pass, key, ipk, meta)

                    ipk.delete()
                    key.delete()
                    meta.version
                }
                status("✅ FÉNIX TV $result instalada correctamente y enviada a abrir en la TV.")
            } catch (e: Exception) {
                status("❌ ${e.message ?: e.javaClass.simpleName}")
            } finally {
                b.progress.visibility = View.GONE
                b.installButton.isEnabled = true
            }
        }
    }

    data class Latest(
        val version: String,
        val fileName: String,
        val sha256: String,
        val downloadUrl: String
    )

    private fun resolveLatest(): Latest {
        val url = "$baseUrl/api/install/resolve?token=${java.net.URLEncoder.encode(token, "UTF-8")}" 
        client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("Enlace vencido o inválido. Regresa a Telegram y pulsa Instalar otra vez.")
            val s = r.body?.string() ?: error("Respuesta vacía del servidor")
            fun value(k: String): String = Regex("\\\"$k\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"")
                .find(s)?.groupValues?.get(1) ?: ""
            val meta = Latest(value("version"), value("fileName"), value("sha256"), value("downloadUrl"))
            if (meta.version.isBlank() || meta.fileName.isBlank() || meta.sha256.isBlank() || meta.downloadUrl.isBlank()) {
                error("Metadatos de instalación incompletos")
            }
            return meta
        }
    }

    private fun download(url: String, fileName: String): File {
        val out = File(cacheDir, fileName)
        client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("No se pudo descargar el IPK (${r.code})")
            out.outputStream().use { os ->
                r.body?.byteStream()?.copyTo(os) ?: error("Descarga vacía")
            }
        }
        return out
    }

    private fun fetchTvKey(ip: String): File {
        val out = File(cacheDir, "webos_rsa")
        client.newCall(Request.Builder().url("http://$ip:9991/webos_rsa").build()).execute().use { r ->
            if (!r.isSuccessful) error("No se pudo obtener la llave. Activa Key Server en Developer Mode.")
            out.outputStream().use { os ->
                r.body?.byteStream()?.copyTo(os) ?: error("Llave vacía")
            }
        }
        return out
    }

    private fun installOverSsh(ip: String, pass: String, key: File, ipk: File, meta: Latest) {
        val ssh = SSHClient()
        ssh.addHostKeyVerifier(PromiscuousVerifier())
        try {
            ssh.connect(ip, 9922)
            val kp = ssh.loadKeys(key.absolutePath, pass)
            ssh.authPublickey("prisoner", kp)

            val remoteDir = "/media/developer/temp"
            val remoteIpk = "$remoteDir/${meta.fileName}"
            val installLog = "$remoteDir/fenix-install.log"

            exec(ssh, "mkdir -p '$remoteDir' && chmod 777 '$remoteDir'")
            ssh.newSFTPClient().use { sftp -> sftp.put(ipk.absolutePath, remoteIpk) }

            statusBlocking("5/6 Instalando FÉNIX TV ${meta.version}…")

            val payload = "{\\\"id\\\":\\\"com.ares.defaultName\\\",\\\"ipkUrl\\\":\\\"$remoteIpk\\\",\\\"subscribe\\\":true}"
            val startCmd = "sh -c 'rm -f $installLog; /usr/bin/luna-send-pub -i -f \\\'luna://com.webos.appInstallService/dev/install\\\' \\\'$payload\\\' > $installLog 2>&1 </dev/null & echo \\$!'"
            val pid = exec(ssh, startCmd, 15000).lineSequence().lastOrNull { it.trim().all(Char::isDigit) }?.trim().orEmpty()

            var installed = false
            var lastLog = ""
            repeat(80) {
                Thread.sleep(1500)
                lastLog = exec(ssh, "cat '$installLog' 2>/dev/null || true", 10000)

                if (lastLog.contains("\\\"returnValue\\\":false", true) ||
                    lastLog.contains("\\\"errorCode\\\"", true) ||
                    lastLog.contains("fail to", true)) {
                    error("La LG rechazó la instalación. ${lastLog.takeLast(900)}")
                }

                if (lastLog.contains("\\\"state\\\":\\\"installed\\\"", true) ||
                    lastLog.contains("\\\"statusValue\\\":30", true)) {
                    installed = true
                    return@repeat
                }

                val versionProbe = exec(
                    ssh,
                    "grep -F '\"version\": \"${meta.version}\"' /media/developer/apps/usr/palm/applications/com.fenixtv.app/appinfo.json 2>/dev/null || true",
                    10000
                )
                if (versionProbe.contains(meta.version)) {
                    installed = true
                    return@repeat
                }
            }

            if (pid.isNotBlank()) exec(ssh, "kill '$pid' 2>/dev/null || true", 10000)
            if (!installed) error("La instalación no confirmó finalización. ${lastLog.takeLast(900)}")

            statusBlocking("6/6 Abriendo FÉNIX TV…")
            exec(
                ssh,
                "/usr/bin/luna-send-pub -n 1 -f 'luna://com.webos.applicationManager/launch' '{\\\"id\\\":\\\"com.fenixtv.app\\\"}'",
                15000
            )
            exec(ssh, "rm -f '$remoteIpk' '$installLog'", 10000)
        } finally {
            try { ssh.disconnect() } catch (_: Exception) { }
        }
    }

    private fun exec(ssh: SSHClient, command: String, timeoutMs: Long = 30000): String {
        ssh.startSession().use { session ->
            val c = session.exec(command)
            c.join(timeoutMs, TimeUnit.MILLISECONDS)
            val out = c.inputStream.bufferedReader().readText()
            val err = c.errorStream.bufferedReader().readText()
            return (out + "\n" + err).trim()
        }
    }

    private fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(128 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun status(s: String) { b.status.text = s }
    private suspend fun statusUi(s: String) = withContext(Dispatchers.Main) { status(s) }
    private fun statusBlocking(s: String) = runBlocking(Dispatchers.Main) { status(s) }
}
