# FÉNIX Installer Android

MVP para instalar/actualizar `com.fenixtv.app` en una LG webOS con Developer Mode.

Flujo:
1. Telegram genera un enlace temporal.
2. Android abre `fenixtvinstaller://install?...`.
3. El usuario escribe IP y passphrase de la TV.
4. La app obtiene la llave desde `http://TV:9991/webos_rsa`.
5. Descarga el IPK desde el Worker, verifica SHA-256, sube por SFTP y llama al instalador de Developer Mode.

La passphrase no se envía al Worker ni a Telegram.
