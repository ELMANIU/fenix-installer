package com.fenixtv.bridge;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String BASE = "https://fenix-installer.elmanuchale.workers.dev";
    private WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);

        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.clearCache(true);
        web.addJavascriptInterface(new Bridge(), "FenixBridge");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !"https".equalsIgnoreCase(u.getScheme())
                        || !"fenix-installer.elmanuchale.workers.dev".equalsIgnoreCase(u.getHost());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                        "if(window.fenixBridgeReady){window.fenixBridgeReady();}",
                        null
                );
            }
        });

        loadFromIntent(getIntent().getData());
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        loadFromIntent(intent.getData());
    }

    private void loadFromIntent(Uri data) {
        String token = "";
        String base = BASE;

        if (data != null && "fenixtvbridge".equalsIgnoreCase(data.getScheme())) {
            String t = data.getQueryParameter("token");
            String b = data.getQueryParameter("base");
            if (t != null && !t.isEmpty()) {
                token = t;
                getSharedPreferences("fenix", MODE_PRIVATE)
                        .edit().putString("last_token", t).apply();
            }
            if (BASE.equals(b)) base = b;
        }

        if (token.isEmpty()) {
            token = getSharedPreferences("fenix", MODE_PRIVATE)
                    .getString("last_token", "");
        }

        String url = base + "/bridge?t=" + enc(token)
                + "&v=3&ts=" + System.currentTimeMillis();
        web.loadUrl(url);
    }

    private static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); }
        catch (Exception e) { return ""; }
    }

    private void progress(String stage, String msg, int percent) {
        final String js = "window.fenixNativeProgress(" +
                JSONObject.quote(stage) + "," +
                JSONObject.quote(msg) + "," + percent + ");";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private void done(boolean ok, String msg) {
        final String js = "window.fenixNativeDone(" + (ok ? "true" : "false") + "," +
                JSONObject.quote(msg) + ");";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    public class Bridge {
        @JavascriptInterface
        public void install(String ip, String passphrase, String token, String base) {
            if (!BASE.equals(base)) {
                done(false, "Servidor no autorizado.");
                return;
            }
            if (!isPrivateIpv4(ip)) {
                done(false, "La IP debe ser una dirección privada de tu red local.");
                return;
            }
            new Thread(() -> installNow(ip, passphrase, token)).start();
        }
    }

    private void installNow(String ip, String passphrase, String token) {
        File ipk = null;
        Session session = null;
        try {
            progress("1/7", "Consultando la última versión…", 8);
            URL resolve = new URL(BASE + "/api/install/resolve?token=" + enc(token));
            JSONObject meta = new JSONObject(readText(resolve, 15000));
            if (!meta.optBoolean("ok")) throw new Exception(meta.optString("error", "No se pudo resolver la versión."));

            String appId = safeAppId(meta.getString("appId"));
            String version = meta.getString("version");
            String fileName = safeFile(meta.getString("fileName"));
            String shaExpected = meta.getString("sha256").toLowerCase(Locale.ROOT);
            String downloadUrl = meta.getString("downloadUrl");
            if (!downloadUrl.startsWith(BASE + "/download/")) throw new Exception("URL de descarga no autorizada.");

            progress("2/7", "Descargando FÉNIX TV " + version + "…", 20);
            ipk = new File(getCacheDir(), fileName);
            downloadTo(new URL(downloadUrl), ipk, 30000);

            progress("3/7", "Verificando SHA‑256…", 34);
            String shaActual = sha256(ipk);
            if (!shaExpected.equalsIgnoreCase(shaActual)) throw new Exception("La verificación SHA‑256 no coincide.");

            progress("4/7", "Obteniendo llave de Developer Mode…", 45);
            byte[] privateKey = readBytes(new URL("http://" + ip + ":9991/webos_rsa"), 12000);
            if (privateKey.length < 100) throw new Exception("La TV no entregó una llave válida. Activa Key Server.");

            progress("5/7", "Conectando con la LG por SSH…", 58);
            JSch jsch = new JSch();
            jsch.addIdentity("webos_rsa", privateKey, null, passphrase.getBytes(StandardCharsets.UTF_8));

            session = jsch.getSession("prisoner", ip, 9922);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setConfig("PreferredAuthentications", "publickey");
            // Compatibilidad con servidores SSH antiguos presentes en algunas LG.
            session.setConfig("server_host_key", session.getConfig("server_host_key") + ",ssh-rsa");
            session.setConfig("PubkeyAcceptedAlgorithms", session.getConfig("PubkeyAcceptedAlgorithms") + ",ssh-rsa");
            session.setConfig("kex", session.getConfig("kex") + ",diffie-hellman-group14-sha1,diffie-hellman-group1-sha1");
            session.connect(15000);

            String remote = "/media/developer/temp/" + fileName;
            progress("6/7", "Copiando el IPK a la TV…", 70);
            ChannelSftp sftp = (ChannelSftp) session.openChannel("sftp");
            sftp.connect(12000);
            try (FileInputStream in = new FileInputStream(ipk)) {
                sftp.put(in, remote);
            }
            sftp.disconnect();

            progress("7/7", "Instalando en webOS…", 84);
            String payload = "{\"id\":\"com.ares.defaultName\",\"ipkUrl\":\"" + remote + "\",\"subscribe\":true}";
            String installCmd = "/usr/bin/luna-send-pub -w 90000 -i 'luna://com.webos.appInstallService/dev/install' '" + payload + "'";
            String out = execUntil(session, installCmd, 105000);
            boolean installed = out.contains("\"state\":\"installed\"")
                    || out.contains("\"statusValue\":30")
                    || out.contains("\"statusValue\": 30");
            if (!installed || out.contains("\"returnValue\":false")) {
                throw new Exception("webOS no confirmó la instalación. " + trimForUser(out));
            }

            progress("Completando", "Abriendo FÉNIX TV…", 95);
            String launchPayload = "{\"id\":\"" + appId + "\"}";
            String launchCmd = "/usr/bin/luna-send-pub -n 1 -w 15000 'luna://com.webos.applicationManager/launch' '" + launchPayload + "'";
            String launch = execUntil(session, launchCmd, 20000);
            execUntil(session, "rm -f '" + remote + "'", 8000);

            if (!launch.contains("\"returnValue\":true")) {
                done(true, "FÉNIX TV " + version + " quedó instalada. No pude confirmar el inicio automático; ábrela desde el launcher de la LG.");
            } else {
                done(true, "✅ FÉNIX TV " + version + " instalada y abierta correctamente.");
            }
        } catch (Exception e) {
            done(false, "❌ " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
        } finally {
            if (session != null && session.isConnected()) session.disconnect();
            if (ipk != null) ipk.delete();
        }
    }

    private static String readText(URL url, int timeout) throws Exception {
        return new String(readBytes(url, timeout), StandardCharsets.UTF_8);
    }

    private static byte[] readBytes(URL url, int timeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "FenixBridge/1.0");
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + " al conectar con " + url.getHost());
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static void downloadTo(URL url, File out, int timeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "FenixBridge/1.0");
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new Exception("No se pudo descargar el IPK (HTTP " + code + ").");
        try (InputStream in = c.getInputStream(); java.io.FileOutputStream fos = new java.io.FileOutputStream(out)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
        } finally {
            c.disconnect();
        }
    }

    private static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) md.update(buf, 0, n);
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static String execUntil(Session session, String command, long timeoutMs) throws Exception {
        ChannelExec ch = (ChannelExec) session.openChannel("exec");
        ch.setCommand(command);
        ch.setInputStream(null);
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        ch.setErrStream(err);
        InputStream in = ch.getInputStream();
        ch.connect(10000);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        long deadline = System.currentTimeMillis() + timeoutMs;

        while (System.currentTimeMillis() < deadline) {
            while (in.available() > 0) {
                int n = in.read(buf, 0, Math.min(buf.length, in.available()));
                if (n < 0) break;
                out.write(buf, 0, n);
                String s = out.toString(StandardCharsets.UTF_8.name());
                if (s.contains("\"state\":\"installed\"")
                        || s.contains("\"statusValue\":30")
                        || s.contains("\"statusValue\": 30")) {
                    ch.disconnect();
                    return s;
                }
            }
            if (ch.isClosed()) break;
            Thread.sleep(120);
        }

        if (ch.isConnected()) ch.disconnect();
        String stdout = out.toString(StandardCharsets.UTF_8.name());
        String stderr = err.toString(StandardCharsets.UTF_8.name());
        return stdout + (stderr.isEmpty() ? "" : "\n" + stderr);
    }

    private static boolean isPrivateIpv4(String ip) {
        if (ip == null || !ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")) return false;
        String[] p = ip.split("\\.");
        int[] n = new int[4];
        try {
            for (int i = 0; i < 4; i++) {
                n[i] = Integer.parseInt(p[i]);
                if (n[i] < 0 || n[i] > 255) return false;
            }
        } catch (Exception e) { return false; }
        return n[0] == 10
                || (n[0] == 192 && n[1] == 168)
                || (n[0] == 172 && n[1] >= 16 && n[1] <= 31);
    }

    private static String safeFile(String s) throws Exception {
        if (s == null || !s.matches("[A-Za-z0-9._-]+\\.ipk")) throw new Exception("Nombre de IPK inválido.");
        return s;
    }

    private static String safeAppId(String s) throws Exception {
        if (s == null || !s.matches("[A-Za-z0-9._-]+")) throw new Exception("App ID inválido.");
        return s;
    }

    private static String trimForUser(String s) {
        if (s == null) return "";
        s = s.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 220 ? s.substring(0, 220) + "…" : s;
    }
}
