package com.fenixtv.bridge;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.text.InputType;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private static final String BASE = "https://fenix-installer.elmanuchale.workers.dev";
    private static final String APP_ID = "com.fenixtv.app";
    private static final String PREFS = "fenix_bridge_pairing";
    private static final String KEY_ALIAS = "fenix_bridge_pairing_key_v1";

    private EditText tvNameField;
    private EditText ipField;
    private EditText passField;

    private LinearLayout setupCard;
    private LinearLayout pairedCard;
    private TextView pairedTitle;
    private TextView pairedMeta;
    private TextView versionInfo;
    private TextView status;
    private TextView sessionStatus;
    private ProgressBar progress;

    private Button pairButton;
    private Button checkButton;
    private Button updateButton;
    private Button changeIpButton;
    private Button relinkButton;
    private Button forgetButton;

    private volatile boolean busy = false;
    private volatile boolean updateAvailable = false;
    private String token = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        readIntent(getIntent());
        buildUi();
        refreshMode();

        if (hasPairing()) {
            checkPairedTv(false);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        boolean gotFreshToken = readIntent(intent);
        refreshMode();

        if (hasPairing()) {
            checkPairedTv(gotFreshToken);
        }
    }

    private boolean readIntent(Intent intent) {
        if (intent == null) return false;
        Uri data = intent.getData();
        if (data != null
                && "fenixtvbridge".equalsIgnoreCase(data.getScheme())
                && "install".equalsIgnoreCase(data.getHost())) {

            String t = data.getQueryParameter("token");
            String b = data.getQueryParameter("base");

            if (t != null && !t.isEmpty() && (b == null || BASE.equals(b))) {
                token = t;
                return true;
            }
        }
        return false;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(7, 9, 15));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(34), dp(22), dp(40));
        scroll.addView(root);

        root.addView(text("🔥 FÉNIX Bridge", 30, Color.WHITE, true));

        TextView subtitle = text(
                "Vincula tu LG una sola vez. Después el Bridge recuerda la TV, comprueba la versión y actualiza con un toque.",
                16,
                Color.rgb(174, 184, 206),
                false
        );
        subtitle.setPadding(0, dp(8), 0, dp(18));
        root.addView(subtitle);

        sessionStatus = text("", 13, Color.rgb(140, 233, 154), true);
        root.addView(sessionStatus);

        setupCard = card();
        root.addView(setupCard);

        setupCard.addView(text("PRIMERA VINCULACIÓN", 14, Color.rgb(140, 233, 154), true));

        TextView firstGuide = text(
                "Solo esta primera vez:\n" +
                "1. Abre Developer Mode en la LG.\n" +
                "2. Activa Dev Mode Status y Key Server.\n" +
                "3. Deja el Android y la TV en la misma Wi‑Fi.\n" +
                "4. Escribe la IP y la passphrase.\n\n" +
                "El Bridge guardará de forma protegida la llave de esta TV. En las siguientes actualizaciones ya no tendrás que volver a escribir estos datos.",
                15,
                Color.rgb(203, 211, 227),
                false
        );
        firstGuide.setLineSpacing(0, 1.22f);
        firstGuide.setPadding(0, dp(12), 0, dp(8));
        setupCard.addView(firstGuide);

        setupCard.addView(label("Nombre de esta TV"));
        tvNameField = field("Mi LG");
        tvNameField.setText("Mi LG");
        setupCard.addView(tvNameField);

        setupCard.addView(label("IP de la LG"));
        ipField = field("192.168.1.86");
        ipField.setInputType(InputType.TYPE_CLASS_PHONE);
        setupCard.addView(ipField);

        setupCard.addView(label("Passphrase de Developer Mode"));
        passField = field("6 caracteres");
        passField.setInputType(
                InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD
        );
        setupCard.addView(passField);

        pairButton = primaryButton("VINCULAR E INSTALAR FÉNIX TV");
        setupCard.addView(pairButton);

        pairedCard = card();
        root.addView(pairedCard);

        pairedCard.addView(text("● LG VINCULADA", 13, Color.rgb(140, 233, 154), true));
        pairedTitle = text("Mi LG", 24, Color.WHITE, true);
        pairedTitle.setPadding(0, dp(10), 0, 0);
        pairedCard.addView(pairedTitle);

        pairedMeta = text("", 13, Color.rgb(143, 154, 176), false);
        pairedMeta.setPadding(0, dp(4), 0, dp(14));
        pairedCard.addView(pairedMeta);

        versionInfo = text("Comprobando FÉNIX TV…", 16, Color.rgb(203, 211, 227), true);
        versionInfo.setPadding(0, dp(4), 0, dp(8));
        pairedCard.addView(versionInfo);

        TextView pairedHint = text(
                "No necesitas volver a escribir la passphrase. Mientras Developer Mode siga activo, FÉNIX Bridge usará la vinculación guardada.",
                13,
                Color.rgb(143, 154, 176),
                false
        );
        pairedHint.setPadding(0, 0, 0, dp(8));
        pairedCard.addView(pairedHint);

        checkButton = secondaryButton("COMPROBAR MI LG");
        pairedCard.addView(checkButton);

        updateButton = primaryButton("ACTUALIZAR MI LG");
        updateButton.setEnabled(false);
        pairedCard.addView(updateButton);

        changeIpButton = secondaryButton("CAMBIAR IP DE LA TV");
        pairedCard.addView(changeIpButton);

        relinkButton = secondaryButton("VOLVER A VINCULAR");
        pairedCard.addView(relinkButton);

        forgetButton = secondaryButton("OLVIDAR ESTA TV");
        pairedCard.addView(forgetButton);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(8));
        pp.topMargin = dp(18);
        root.addView(progress, pp);

        status = text("Listo.", 14, Color.rgb(203, 211, 227), false);
        status.setPadding(0, dp(16), 0, 0);
        root.addView(status);

        TextView privacy = text(
                "La IP, la llave de Developer Mode y la passphrase se guardan únicamente en este Android. La llave y la passphrase se cifran con Android Keystore. No se envían a Telegram ni a Cloudflare.",
                13,
                Color.rgb(143, 154, 176),
                false
        );
        privacy.setPadding(0, dp(18), 0, 0);
        root.addView(privacy);

        pairButton.setOnClickListener(v -> startPairing());
        checkButton.setOnClickListener(v -> checkPairedTv(false));
        updateButton.setOnClickListener(v -> startPairedUpdate());
        changeIpButton.setOnClickListener(v -> showChangeIpDialog());
        relinkButton.setOnClickListener(v -> confirmRelink());
        forgetButton.setOnClickListener(v -> confirmForget());

        setContentView(scroll);
    }

    private void refreshMode() {
        boolean paired = hasPairing();
        setupCard.setVisibility(paired ? View.GONE : View.VISIBLE);
        pairedCard.setVisibility(paired ? View.VISIBLE : View.GONE);

        if (paired) {
            SharedPreferences p = prefs();
            String name = p.getString("tv_name", "Mi LG");
            String ip = p.getString("tv_ip", "");
            pairedTitle.setText(name == null || name.trim().isEmpty() ? "Mi LG" : name);
            pairedMeta.setText(ip.isEmpty() ? "TV vinculada" : "IP guardada: " + ip);
            sessionStatus.setText("● TV RECORDADA · LISTA PARA COMPROBAR");
            sessionStatus.setTextColor(Color.rgb(140, 233, 154));
        } else {
            sessionStatus.setText("● CONFIGURACIÓN INICIAL");
            sessionStatus.setTextColor(Color.rgb(255, 212, 117));
        }
    }

    private void startPairing() {
        if (!beginBusy()) return;

        String name = tvNameField.getText().toString().trim();
        String ip = ipField.getText().toString().trim();
        String pass = passField.getText().toString().trim();

        if (name.isEmpty()) name = "Mi LG";

        if (!isPrivateIpv4(ip)) {
            endBusy();
            fail("Escribe una IP privada válida, por ejemplo 192.168.1.86.");
            return;
        }
        if (pass.length() < 4) {
            endBusy();
            fail("Escribe la passphrase mostrada por Developer Mode.");
            return;
        }

        final String tvName = name;
        final String tvIp = ip;
        final String tvPass = pass;

        new Thread(() -> {
            Session session = null;
            try {
                step(8, "Obteniendo la llave de Developer Mode…");
                byte[] privateKey = readBytes(
                        new URL("http://" + tvIp + ":9991/webos_rsa"),
                        12000
                );

                if (privateKey.length < 100) {
                    throw new Exception("La TV no entregó una llave válida. Confirma que Key Server esté activado.");
                }

                Credentials c = new Credentials(tvName, tvIp, tvPass, privateKey);

                step(20, "Probando la conexión con la LG…");
                session = openSession(c);

                String installed = queryInstalledVersion(session, APP_ID);
                step(28, installed.isEmpty()
                        ? "LG vinculada. FÉNIX TV todavía no está instalada."
                        : "LG vinculada. FÉNIX TV instalada: " + installed);

                savePairing(c);

                if (session != null && session.isConnected()) {
                    session.disconnect();
                    session = null;
                }

                runOnUiThread(() -> {
                    passField.setText("");
                    refreshMode();
                });

                step(34, "Vinculación guardada de forma segura.");
                installLatest(c);

            } catch (Exception e) {
                failUser(e);
            } finally {
                if (session != null && session.isConnected()) session.disconnect();
                endBusy();
            }
        }).start();
    }

    private void checkPairedTv(boolean autoUpdateIfNeeded) {
        if (!hasPairing() || !beginBusy()) return;

        new Thread(() -> {
            Session session = null;
            try {
                Credentials c = loadPairing();
                step(10, "Consultando la última versión publicada…");
                JSONObject latest = fetchLatest();
                String latestVersion = latest.getString("version");
                String appId = safeAppId(latest.optString("appId", APP_ID));

                step(30, "Conectando con " + c.name + "…");
                session = openSession(c);

                step(52, "Leyendo la versión instalada…");
                String installed = queryInstalledVersion(session, appId);

                if (session != null && session.isConnected()) {
                    session.disconnect();
                    session = null;
                }

                boolean needsUpdate = installed.isEmpty() || compareVersions(installed, latestVersion) < 0;
                showVersionState(installed, latestVersion, needsUpdate);

                if (!needsUpdate) {
                    success("✅ Estás al día. FÉNIX TV " + latestVersion + " ya está instalada en " + c.name + ".");
                    return;
                }

                if (autoUpdateIfNeeded) {
                    step(60, "Actualización disponible. Preparando instalación automática…");
                    installLatest(c);
                } else {
                    step(100, installed.isEmpty()
                            ? "FÉNIX TV no está instalada. Pulsa ACTUALIZAR MI LG para instalarla."
                            : "⬆️ Nueva versión " + latestVersion + " disponible. Pulsa ACTUALIZAR MI LG.");
                }

            } catch (Exception e) {
                showConnectionHelp(e);
            } finally {
                if (session != null && session.isConnected()) session.disconnect();
                endBusy();
            }
        }).start();
    }

    private void startPairedUpdate() {
        if (!hasPairing() || !beginBusy()) return;

        new Thread(() -> {
            try {
                Credentials c = loadPairing();
                installLatest(c);
            } catch (Exception e) {
                showConnectionHelp(e);
            } finally {
                endBusy();
            }
        }).start();
    }

    private void installLatest(Credentials c) throws Exception {
        File ipk = null;
        Session session = null;

        try {
            step(8, "Creando una sesión segura de actualización…");
            String installToken = requestInstallToken();

            step(14, "Consultando la versión publicada…");
            JSONObject meta = resolveInstall(installToken);

            String appId = safeAppId(meta.getString("appId"));
            String version = meta.getString("version");
            String fileName = safeFile(meta.getString("fileName"));
            String shaExpected = meta.getString("sha256").toLowerCase(Locale.ROOT);
            String downloadUrl = meta.getString("downloadUrl");

            if (!downloadUrl.startsWith(BASE + "/download/")) {
                throw new Exception("URL de descarga no autorizada.");
            }

            step(24, "Conectando con " + c.name + "…");
            session = openSession(c);

            step(32, "Comprobando la versión instalada…");
            String installedVersion = queryInstalledVersion(session, appId);

            if (version.equals(installedVersion)) {
                showVersionState(installedVersion, version, false);
                success("✅ Estás al día. FÉNIX TV " + version + " ya está instalada.");
                return;
            }

            step(42, "Descargando FÉNIX TV " + version + "…");
            ipk = new File(getCacheDir(), fileName);
            downloadTo(new URL(downloadUrl), ipk, 30000);

            step(52, "Verificando SHA‑256…");
            String shaActual = sha256(ipk);
            if (!shaExpected.equalsIgnoreCase(shaActual)) {
                throw new Exception("La verificación SHA‑256 no coincide.");
            }

            String remote = "/media/developer/temp/" + fileName;

            step(64, "Copiando el IPK a la LG…");
            ChannelSftp sftp = (ChannelSftp) session.openChannel("sftp");
            sftp.connect(12000);

            try (FileInputStream in = new FileInputStream(ipk)) {
                sftp.put(in, remote);
            }
            sftp.disconnect();

            step(78, "Instalando FÉNIX TV " + version + "…");

            String payload =
                    "{\"id\":\"com.ares.defaultName\",\"ipkUrl\":\""
                            + remote
                            + "\",\"subscribe\":true}";

            String installCmd =
                    "/usr/bin/luna-send-pub -n 60 -w 90000 " +
                    "'luna://com.webos.appInstallService/dev/install' " +
                    "'" + payload + "'";

            String out = execCollect(session, installCmd, 105000);

            boolean installed =
                    out.contains("\"state\":\"installed\"")
                    || out.contains("\"statusValue\":30")
                    || out.contains("\"statusValue\": 30");

            if (!installed && (
                    out.contains("\"statusValue\":24")
                    || out.contains("\"statusValue\": 24")
                    || (
                        out.contains("\"returnValue\":false")
                        && !out.contains("install has been disconnected")
                    )
            )) {
                throw new Exception(
                        "webOS reportó un error durante la instalación. "
                                + summarizeInstallState(out)
                );
            }

            if (!installed) {
                step(88, "Verificando la instalación…");
                String verifyVersion = queryInstalledVersion(session, appId);
                installed = version.equals(verifyVersion);
            }

            if (!installed) {
                throw new Exception(
                        "La instalación no llegó a un estado final. "
                                + summarizeInstallState(out)
                );
            }

            step(94, "Abriendo FÉNIX TV…");
            String launchPayload = "{\"id\":\"" + appId + "\"}";
            String launchCmd =
                    "/usr/bin/luna-send-pub -n 1 -w 15000 " +
                    "'luna://com.webos.applicationManager/launch' " +
                    "'" + launchPayload + "'";

            String launch = execUntil(session, launchCmd, 20000);
            execUntil(session, "rm -f '" + remote + "'", 8000);

            showVersionState(version, version, false);

            if (launch.contains("\"returnValue\":true")) {
                success("✅ FÉNIX TV " + version + " actualizada y abierta correctamente.");
            } else {
                success("✅ FÉNIX TV " + version + " quedó actualizada. Ábrela desde el launcher de la LG.");
            }

        } finally {
            if (session != null && session.isConnected()) session.disconnect();
            if (ipk != null && ipk.exists()) ipk.delete();
        }
    }

    private JSONObject fetchLatest() throws Exception {
        JSONObject latest = new JSONObject(readText(
                new URL(BASE + "/api/latest?ts=" + System.currentTimeMillis()),
                15000
        ));
        if (!latest.optBoolean("ok")) {
            throw new Exception(latest.optString("error", "No se pudo consultar la última versión."));
        }
        return latest;
    }

    private String requestInstallToken() throws Exception {
        JSONObject session = new JSONObject(readText(
                new URL(BASE + "/api/install/session?ts=" + System.currentTimeMillis()),
                15000
        ));
        if (!session.optBoolean("ok")) {
            throw new Exception(session.optString("error", "No se pudo crear la sesión de actualización."));
        }
        String t = session.optString("token", "");
        if (t.isEmpty()) throw new Exception("El servidor no entregó un token de instalación.");
        token = t;
        return t;
    }

    private JSONObject resolveInstall(String installToken) throws Exception {
        URL resolve = new URL(
                BASE + "/api/install/resolve?token=" + enc(installToken)
        );
        JSONObject meta = new JSONObject(readText(resolve, 15000));
        if (!meta.optBoolean("ok")) {
            throw new Exception(meta.optString("error", "No se pudo resolver la versión."));
        }
        return meta;
    }

    private Session openSession(Credentials c) throws Exception {
        JSch jsch = new JSch();
        jsch.addIdentity(
                "webos_rsa",
                c.privateKey,
                null,
                c.passphrase.getBytes(StandardCharsets.UTF_8)
        );

        Session session = jsch.getSession("prisoner", c.ip, 9922);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setConfig("PreferredAuthentications", "publickey");
        session.setConfig(
                "server_host_key",
                session.getConfig("server_host_key") + ",ssh-rsa"
        );
        session.setConfig(
                "PubkeyAcceptedAlgorithms",
                session.getConfig("PubkeyAcceptedAlgorithms") + ",ssh-rsa"
        );
        session.setConfig(
                "kex",
                session.getConfig("kex")
                        + ",diffie-hellman-group14-sha1,diffie-hellman-group1-sha1"
        );
        session.connect(15000);
        return session;
    }

    private String queryInstalledVersion(Session session, String appId) throws Exception {
        String installedInfo = execCollect(
                session,
                "cat '/media/developer/apps/usr/palm/applications/" + appId + "/appinfo.json' 2>/dev/null || true",
                10000
        );
        return extractJsonString(installedInfo, "version");
    }

    private void showVersionState(String installed, String latest, boolean needsUpdate) {
        runOnUiThread(() -> {
            String installedLabel = installed == null || installed.isEmpty() ? "No instalada" : installed;
            versionInfo.setText(
                    "Instalada: " + installedLabel + "\n" +
                    "Disponible: " + latest
            );
            updateAvailable = needsUpdate;
            versionInfo.setTextColor(needsUpdate
                    ? Color.rgb(255, 212, 117)
                    : Color.rgb(140, 233, 154));
            updateButton.setEnabled(needsUpdate && !busy);
            updateButton.setText(needsUpdate ? "ACTUALIZAR MI LG" : "ESTÁS AL DÍA");
        });
    }

    private void showConnectionHelp(Exception e) {
        String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        fail(
                "❌ No pude conectar con la LG guardada.\n\n" +
                msg + "\n\n" +
                "Comprueba que la TV esté encendida, en la misma Wi‑Fi y que Developer Mode siga activo. " +
                "Si solo cambió la IP, usa CAMBIAR IP. Si LG renovó la llave, usa VOLVER A VINCULAR."
        );
        runOnUiThread(() -> updateButton.setEnabled(false));
    }

    private void showChangeIpDialog() {
        if (!hasPairing() || busy) return;

        EditText input = field("192.168.1.86");
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        input.setText(prefs().getString("tv_ip", ""));

        new AlertDialog.Builder(this)
                .setTitle("Cambiar IP de la LG")
                .setMessage("No necesitas volver a escribir la passphrase. Escribe únicamente la nueva IP de la misma televisión.")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", (d, w) -> {
                    String ip = input.getText().toString().trim();
                    if (!isPrivateIpv4(ip)) {
                        fail("La IP no es válida.");
                        return;
                    }
                    prefs().edit().putString("tv_ip", ip).apply();
                    refreshMode();
                    checkPairedTv(false);
                })
                .show();
    }

    private void confirmRelink() {
        if (busy) return;
        new AlertDialog.Builder(this)
                .setTitle("Volver a vincular")
                .setMessage("Úsalo si LG cambió la llave de Developer Mode. Tendrás que activar Key Server y escribir de nuevo la IP y passphrase una sola vez.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Continuar", (d, w) -> {
                    String oldName = prefs().getString("tv_name", "Mi LG");
                    String oldIp = prefs().getString("tv_ip", "");
                    clearPairing(false);
                    tvNameField.setText(oldName);
                    ipField.setText(oldIp);
                    passField.setText("");
                    refreshMode();
                    setStatus("Activa Key Server en la LG y vuelve a vincularla.", false);
                })
                .show();
    }

    private void confirmForget() {
        if (busy) return;
        new AlertDialog.Builder(this)
                .setTitle("Olvidar esta TV")
                .setMessage("Se borrarán del teléfono la IP, la llave y la passphrase guardadas.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Olvidar", (d, w) -> {
                    clearPairing(true);
                    refreshMode();
                    progress.setProgress(0);
                    versionInfo.setText("Comprobando FÉNIX TV…");
                    setStatus("TV olvidada. Puedes vincular otra LG.", false);
                })
                .show();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private boolean hasPairing() {
        SharedPreferences p = prefs();
        return p.getBoolean("paired", false)
                && !p.getString("tv_ip", "").isEmpty()
                && !p.getString("key_blob", "").isEmpty()
                && !p.getString("pass_blob", "").isEmpty();
    }

    private void savePairing(Credentials c) throws Exception {
        prefs().edit()
                .putBoolean("paired", true)
                .putString("tv_name", c.name)
                .putString("tv_ip", c.ip)
                .putString("key_blob", encrypt(c.privateKey))
                .putString("pass_blob", encrypt(c.passphrase.getBytes(StandardCharsets.UTF_8)))
                .apply();
    }

    private Credentials loadPairing() throws Exception {
        SharedPreferences p = prefs();
        if (!hasPairing()) throw new Exception("No hay una LG vinculada.");

        String name = p.getString("tv_name", "Mi LG");
        String ip = p.getString("tv_ip", "");
        byte[] key = decrypt(p.getString("key_blob", ""));
        String pass = new String(
                decrypt(p.getString("pass_blob", "")),
                StandardCharsets.UTF_8
        );

        if (!isPrivateIpv4(ip) || key.length < 100 || pass.length() < 4) {
            throw new Exception("La vinculación guardada está incompleta. Vuelve a vincular la LG.");
        }
        return new Credentials(name, ip, pass, key);
    }

    private void clearPairing(boolean deleteKeyAlias) {
        prefs().edit().clear().apply();
        token = "";
        updateAvailable = false;

        if (deleteKeyAlias) {
            try {
                KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
                ks.load(null);
                if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS);
            } catch (Exception ignored) {
            }
        }
    }

    private String encrypt(byte[] clear) throws Exception {
        SecretKey key = getOrCreateSecretKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = cipher.getIV();
        byte[] encrypted = cipher.doFinal(clear);
        byte[] out = new byte[iv.length + encrypted.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(encrypted, 0, out, iv.length, encrypted.length);
        return Base64.encodeToString(out, Base64.NO_WRAP);
    }

    private byte[] decrypt(String encoded) throws Exception {
        byte[] all = Base64.decode(encoded, Base64.NO_WRAP);
        if (all.length < 13) throw new Exception("Datos protegidos inválidos.");
        byte[] iv = Arrays.copyOfRange(all, 0, 12);
        byte[] ciphertext = Arrays.copyOfRange(all, 12, all.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), new GCMParameterSpec(128, iv));
        return cipher.doFinal(ciphertext);
    }

    private SecretKey getOrCreateSecretKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            KeyStore.SecretKeyEntry entry = (KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null);
            return entry.getSecretKey();
        }

        KeyGenerator generator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                "AndroidKeyStore"
        );
        generator.init(new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT
        )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return generator.generateKey();
    }

    private static class Credentials {
        final String name;
        final String ip;
        final String passphrase;
        final byte[] privateKey;

        Credentials(String name, String ip, String passphrase, byte[] privateKey) {
            this.name = name == null || name.trim().isEmpty() ? "Mi LG" : name.trim();
            this.ip = ip;
            this.passphrase = passphrase;
            this.privateKey = privateKey;
        }
    }

    private boolean beginBusy() {
        if (busy) return false;
        busy = true;
        runOnUiThread(() -> {
            pairButton.setEnabled(false);
            checkButton.setEnabled(false);
            updateButton.setEnabled(false);
            changeIpButton.setEnabled(false);
            relinkButton.setEnabled(false);
            forgetButton.setEnabled(false);
        });
        return true;
    }

    private void endBusy() {
        busy = false;
        runOnUiThread(() -> {
            pairButton.setEnabled(true);
            checkButton.setEnabled(true);
            updateButton.setEnabled(updateAvailable && hasPairing());
            changeIpButton.setEnabled(true);
            relinkButton.setEnabled(true);
            forgetButton.setEnabled(true);
        });
    }

    private void step(int p, String msg) {
        runOnUiThread(() -> {
            progress.setProgress(Math.max(0, Math.min(100, p)));
            status.setText(msg);
            status.setTextColor(Color.rgb(203, 211, 227));
        });
    }

    private void success(String msg) {
        runOnUiThread(() -> {
            progress.setProgress(100);
            status.setText(msg);
            status.setTextColor(Color.rgb(140, 233, 154));
        });
    }

    private void fail(String msg) {
        runOnUiThread(() -> {
            progress.setProgress(0);
            status.setText(msg);
            status.setTextColor(Color.rgb(255, 135, 135));
        });
    }

    private void failUser(Exception e) {
        fail("❌ " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
    }

    private void setStatus(String msg, boolean ok) {
        status.setText(msg);
        status.setTextColor(ok ? Color.rgb(140, 233, 154) : Color.rgb(203, 211, 227));
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackgroundColor(Color.rgb(17, 22, 36));

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cp.topMargin = dp(10);
        card.setLayoutParams(cp);
        return card;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, Color.rgb(174, 184, 206), false);
        t.setPadding(0, dp(14), 0, dp(6));
        return t;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(110, 122, 148));
        e.setTextColor(Color.WHITE);
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackgroundColor(Color.rgb(11, 16, 26));
        e.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(54)
        ));
        return e;
    }

    private Button primaryButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(123, 44, 255));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        p.topMargin = dp(14);
        b.setLayoutParams(p);
        return b;
    }

    private Button secondaryButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setBackgroundColor(Color.rgb(32, 42, 64));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50));
        p.topMargin = dp(10);
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static int compareVersions(String a, String b) {
        int[] av = versionParts(a);
        int[] bv = versionParts(b);
        int n = Math.max(av.length, bv.length);
        for (int i = 0; i < n; i++) {
            int x = i < av.length ? av[i] : 0;
            int y = i < bv.length ? bv[i] : 0;
            if (x != y) return Integer.compare(x, y);
        }
        return 0;
    }

    private static int[] versionParts(String s) {
        if (s == null) return new int[0];
        String[] p = s.split("[^0-9]+");
        java.util.ArrayList<Integer> out = new java.util.ArrayList<>();
        for (String part : p) {
            if (part.isEmpty()) continue;
            try { out.add(Integer.parseInt(part)); } catch (Exception ignored) { out.add(0); }
        }
        int[] r = new int[out.size()];
        for (int i = 0; i < out.size(); i++) r[i] = out.get(i);
        return r;
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static String readText(URL url, int timeout) throws Exception {
        return new String(readBytes(url, timeout), StandardCharsets.UTF_8);
    }

    private static byte[] readBytes(URL url, int timeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "FenixBridge/1.2");

        int code = c.getResponseCode();
        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code + " al conectar con " + url.getHost());
        }

        try (
                InputStream in = c.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream()
        ) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static void downloadTo(URL url, File out, int timeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "FenixBridge/1.2");

        int code = c.getResponseCode();
        if (code < 200 || code >= 300) {
            throw new Exception("No se pudo descargar el IPK (HTTP " + code + ").");
        }

        try (
                InputStream in = c.getInputStream();
                java.io.FileOutputStream fos = new java.io.FileOutputStream(out)
        ) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) fos.write(buf, 0, n);
        } finally {
            c.disconnect();
        }
    }

    private static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) md.update(buf, 0, n);
        }

        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static String execCollect(Session session, String command, long timeoutMs) throws Exception {
        ChannelExec ch = (ChannelExec) session.openChannel("exec");
        ch.setCommand(command);
        ch.setInputStream(null);

        ByteArrayOutputStream err = new ByteArrayOutputStream();
        ch.setErrStream(err);

        InputStream in = ch.getInputStream();
        ch.connect(10000);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        long deadline = System.currentTimeMillis() + timeoutMs;

        while (System.currentTimeMillis() < deadline) {
            boolean readSomething = false;

            while (in.available() > 0) {
                int n = in.read(buf, 0, Math.min(buf.length, in.available()));
                if (n < 0) break;
                out.write(buf, 0, n);
                readSomething = true;

                String s = out.toString(StandardCharsets.UTF_8.name());
                if (s.contains("\"statusValue\":30")
                        || s.contains("\"statusValue\": 30")
                        || s.contains("\"state\":\"installed\"")
                        || s.contains("\"statusValue\":24")
                        || s.contains("\"statusValue\": 24")
                        || s.contains("\"returnValue\":false")) {
                    if (ch.isConnected()) ch.disconnect();
                    String stderr = err.toString(StandardCharsets.UTF_8.name());
                    return s + (stderr.isEmpty() ? "" : "\\n" + stderr);
                }
            }

            if (ch.isClosed()) {
                while (in.available() > 0) {
                    int n = in.read(buf, 0, Math.min(buf.length, in.available()));
                    if (n < 0) break;
                    out.write(buf, 0, n);
                }
                break;
            }

            if (!readSomething) Thread.sleep(120);
        }

        if (ch.isConnected()) ch.disconnect();

        String stdout = out.toString(StandardCharsets.UTF_8.name());
        String stderr = err.toString(StandardCharsets.UTF_8.name());
        return stdout + (stderr.isEmpty() ? "" : "\\n" + stderr);
    }

    private static String execUntil(Session session, String command, long timeoutMs) throws Exception {
        return execCollect(session, command, timeoutMs);
    }

    private static String summarizeInstallState(String s) {
        if (s == null || s.isEmpty()) return "Sin respuesta del instalador de webOS.";

        String statusValue = "";
        java.util.regex.Matcher sm = java.util.regex.Pattern
                .compile("\"statusValue\"\\s*:\\s*(\\d+)")
                .matcher(s);
        while (sm.find()) statusValue = sm.group(1);

        String reason = "";
        java.util.regex.Matcher rm = java.util.regex.Pattern
                .compile("\"reason\"\\s*:\\s*\"([^\"]*)\"")
                .matcher(s);
        while (rm.find()) reason = rm.group(1);

        if (!statusValue.isEmpty()) {
            String label;
            switch (statusValue) {
                case "268": label = "Verificando el IPK (268)."; break;
                case "269": label = "Solicitando verificación del IPK (269)."; break;
                case "270": label = "Verificación del IPK completada (270)."; break;
                case "271": label = "Verificación adicional requerida (271)."; break;
                case "272": label = "Verificación adicional solicitada (272)."; break;
                case "273": label = "Verificación adicional completada (273)."; break;
                case "30": label = "Instalación completada correctamente (30)."; break;
                case "24": label = "Error instalando el IPK (24)."; break;
                default: label = "Estado de instalación " + statusValue + "."; break;
            }
            return label + (reason.isEmpty() ? "" : " " + reason);
        }

        return trimForUser(s);
    }

    private static boolean isPrivateIpv4(String ip) {
        if (ip == null || !ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")) return false;

        String[] p = ip.split("\\.");
        int[] n = new int[4];
        try {
            for (int i = 0; i < 4; i++) {
                n[i] = Integer.parseInt(p[i]);
                if (n[i] < 0 || n[i] > 255) return false;
            }
        } catch (Exception e) {
            return false;
        }

        return n[0] == 10
                || (n[0] == 192 && n[1] == 168)
                || (n[0] == 172 && n[1] >= 16 && n[1] <= 31);
    }

    private static String extractJsonString(String json, String key) {
        if (json == null || key == null) return "";
        try {
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("\"" + java.util.regex.Pattern.quote(key) + "\"\\s*:\\s*\"([^\"]*)\"")
                    .matcher(json);
            return m.find() ? m.group(1) : "";
        } catch (Exception e) {
            return "";
        }
    }

    private static String safeFile(String s) throws Exception {
        if (s == null || !s.matches("[A-Za-z0-9._-]+\\.ipk")) {
            throw new Exception("Nombre de IPK inválido.");
        }
        return s;
    }

    private static String safeAppId(String s) throws Exception {
        if (s == null || !s.matches("[A-Za-z0-9._-]+")) {
            throw new Exception("App ID inválido.");
        }
        return s;
    }

    private static String trimForUser(String s) {
        if (s == null) return "";
        s = s.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 220 ? s.substring(0, 220) + "…" : s;
    }
}
