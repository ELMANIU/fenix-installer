package com.fenixtv.bridge;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String BASE = "https://fenix-installer.elmanuchale.workers.dev";

    private EditText ipField;
    private EditText passField;
    private Button installButton;
    private ProgressBar progress;
    private TextView status;
    private TextView sessionStatus;

    private String token = "";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        readIntent(getIntent());
        buildUi();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readIntent(intent);
        refreshSessionUi();
    }

    private void readIntent(Intent intent) {
        if (intent == null) return;
        Uri data = intent.getData();
        if (data != null
                && "fenixtvbridge".equalsIgnoreCase(data.getScheme())
                && "install".equalsIgnoreCase(data.getHost())) {

            String t = data.getQueryParameter("token");
            String b = data.getQueryParameter("base");

            if (t != null && !t.isEmpty() && (b == null || BASE.equals(b))) {
                token = t;
                getSharedPreferences("fenix", MODE_PRIVATE)
                        .edit()
                        .putString("last_token", token)
                        .apply();
                return;
            }
        }

        token = getSharedPreferences("fenix", MODE_PRIVATE)
                .getString("last_token", "");
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(7, 9, 15));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(34), dp(22), dp(40));
        scroll.addView(root);

        TextView title = text("🔥 FÉNIX Bridge", 30, Color.WHITE, true);
        root.addView(title);

        TextView subtitle = text(
                "Instala o actualiza FÉNIX TV en tu LG webOS desde este teléfono.",
                16,
                Color.rgb(174, 184, 206),
                false
        );
        subtitle.setPadding(0, dp(8), 0, dp(18));
        root.addView(subtitle);

        LinearLayout card = card();
        root.addView(card);

        sessionStatus = text("", 13, Color.rgb(140, 233, 154), true);
        card.addView(sessionStatus);

        TextView guide = text(
                "1. En la LG abre Developer Mode.\n" +
                "2. Activa Dev Mode Status y Key Server.\n" +
                "3. Conecta el teléfono a la misma Wi‑Fi.\n" +
                "4. Escribe la IP y la passphrase mostradas por la TV.",
                16,
                Color.rgb(203, 211, 227),
                false
        );
        guide.setLineSpacing(0, 1.25f);
        guide.setPadding(0, dp(12), 0, dp(8));
        card.addView(guide);

        card.addView(label("IP de la LG"));
        ipField = field("192.168.1.86");
        ipField.setInputType(InputType.TYPE_CLASS_PHONE);
        card.addView(ipField);

        card.addView(label("Passphrase"));
        passField = field("6 caracteres");
        passField.setInputType(
                InputType.TYPE_CLASS_TEXT |
                InputType.TYPE_TEXT_VARIATION_PASSWORD
        );
        card.addView(passField);

        installButton = new Button(this);
        installButton.setText("INSTALAR FÉNIX TV");
        installButton.setTextColor(Color.WHITE);
        installButton.setTextSize(16);
        installButton.setTypeface(Typeface.DEFAULT_BOLD);
        installButton.setAllCaps(false);
        installButton.setBackgroundColor(Color.rgb(123, 44, 255));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(56));
        bp.topMargin = dp(18);
        card.addView(installButton, bp);

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(8));
        pp.topMargin = dp(18);
        card.addView(progress, pp);

        status = text("Listo para comenzar.", 14, Color.rgb(203, 211, 227), false);
        status.setPadding(0, dp(16), 0, 0);
        card.addView(status);

        TextView privacy = text(
                "La IP y la passphrase se usan únicamente en este teléfono. " +
                "El IPK se descarga temporalmente, se verifica con SHA‑256 y se elimina al finalizar.",
                13,
                Color.rgb(143, 154, 176),
                false
        );
        privacy.setPadding(0, dp(18), 0, 0);
        root.addView(privacy);

        installButton.setOnClickListener(v -> startInstall());
        refreshSessionUi();

        setContentView(scroll);
    }

    private void refreshSessionUi() {
        if (sessionStatus == null) return;
        if (token == null || token.isEmpty()) {
            sessionStatus.setText("⚠ Abre FÉNIX Bridge desde el botón del bot de Telegram para autorizar la instalación.");
            sessionStatus.setTextColor(Color.rgb(255, 212, 117));
        } else {
            sessionStatus.setText("● SESIÓN DE INSTALACIÓN LISTA");
            sessionStatus.setTextColor(Color.rgb(140, 233, 154));
        }
    }

    private void startInstall() {
        String ip = ipField.getText().toString().trim();
        String pass = passField.getText().toString().trim();

        if (token == null || token.isEmpty()) {
            fail("Abre el bot de Telegram, escribe /start y entra desde el botón INSTALAR FÉNIX TV.");
            return;
        }
        if (!isPrivateIpv4(ip)) {
            fail("Escribe una IP privada válida, por ejemplo 192.168.1.86.");
            return;
        }
        if (pass.length() < 4) {
            fail("Escribe la passphrase mostrada por Developer Mode.");
            return;
        }

        installButton.setEnabled(false);
        progress.setProgress(2);
        setStatus("Iniciando…", false);

        new Thread(() -> installNow(ip, pass, token)).start();
    }

    private void installNow(String ip, String passphrase, String installToken) {
        File ipk = null;
        Session session = null;
        try {
            step(8, "Consultando la última versión…");

            URL resolve = new URL(
                    BASE + "/api/install/resolve?token=" + enc(installToken)
            );

            JSONObject meta = new JSONObject(readText(resolve, 15000));

            if (!meta.optBoolean("ok")) {
                throw new Exception(
                        meta.optString("error", "No se pudo resolver la versión.")
                );
            }

            String appId = safeAppId(meta.getString("appId"));
            String version = meta.getString("version");
            String fileName = safeFile(meta.getString("fileName"));
            String shaExpected = meta.getString("sha256").toLowerCase(Locale.ROOT);
            String downloadUrl = meta.getString("downloadUrl");

            if (!downloadUrl.startsWith(BASE + "/download/")) {
                throw new Exception("URL de descarga no autorizada.");
            }

            step(20, "Descargando FÉNIX TV " + version + "…");
            ipk = new File(getCacheDir(), fileName);
            downloadTo(new URL(downloadUrl), ipk, 30000);

            step(34, "Verificando SHA‑256…");
            String shaActual = sha256(ipk);
            if (!shaExpected.equalsIgnoreCase(shaActual)) {
                throw new Exception("La verificación SHA‑256 no coincide.");
            }

            step(45, "Obteniendo la llave de Developer Mode…");
            byte[] privateKey = readBytes(
                    new URL("http://" + ip + ":9991/webos_rsa"),
                    12000
            );

            if (privateKey.length < 100) {
                throw new Exception(
                        "La TV no entregó una llave válida. Confirma que Key Server esté activado."
                );
            }

            step(58, "Conectando con la LG…");

            JSch jsch = new JSch();
            jsch.addIdentity(
                    "webos_rsa",
                    privateKey,
                    null,
                    passphrase.getBytes(StandardCharsets.UTF_8)
            );

            session = jsch.getSession("prisoner", ip, 9922);
            session.setConfig("StrictHostKeyChecking", "no");
            session.setConfig("PreferredAuthentications", "publickey");
            session.setConfig(
                    "server_host_key",
                    session.getConfig("server_host_key") + ",ssh-rsa"
            );
            session.setConfig(
                    "PubkeyAcceptedAlgorithms",
                    session.getConfig("PubkeyAcceptedAlgorithms") + ",ssh-rsa"
            );
            session.setConfig(
                    "kex",
                    session.getConfig("kex")
                            + ",diffie-hellman-group14-sha1,diffie-hellman-group1-sha1"
            );
            session.connect(15000);

            String remote = "/media/developer/temp/" + fileName;

            step(70, "Copiando el IPK a la LG…");
            ChannelSftp sftp = (ChannelSftp) session.openChannel("sftp");
            sftp.connect(12000);

            try (FileInputStream in = new FileInputStream(ipk)) {
                sftp.put(in, remote);
            }

            sftp.disconnect();

            step(84, "Instalando FÉNIX TV en webOS…");

            String payload =
                    "{\"id\":\"com.ares.defaultName\",\"ipkUrl\":\""
                            + remote
                            + "\",\"subscribe\":true}";

            // dev/install emite múltiples estados intermedios. 268 NO es un error:
            // significa "Need to verify ipk file". Recogemos varias respuestas
            // y esperamos un estado terminal real.
            String installCmd =
                    "/usr/bin/luna-send-pub -n 60 -w 90000 " +
                    "'luna://com.webos.appInstallService/dev/install' " +
                    "'" + payload + "'";

            String out = execCollect(session, installCmd, 105000);

            boolean installed =
                    out.contains("\"state\":\"installed\"")
                    || out.contains("\"statusValue\":30")
                    || out.contains("\"statusValue\": 30");

            // webOS puede enviar después del estado 30:
            // {"returnValue":false,"errorCode":-1,"errorText":"install has been disconnected."}
            // Eso NO invalida una instalación que ya llegó a 30 / installed.
            if (!installed && (
                    out.contains("\"statusValue\":24")
                    || out.contains("\"statusValue\": 24")
                    || (
                        out.contains("\"returnValue\":false")
                        && !out.contains("install has been disconnected")
                    )
            )) {
                throw new Exception(
                        "webOS reportó un error durante la instalación. "
                                + summarizeInstallState(out)
                );
            }

            // Algunas versiones de webOS pueden cerrar la suscripción antes de
            // devolver el 30. Verificamos directamente el appinfo instalado.
            if (!installed) {
                step(91, "Verificando que FÉNIX TV quedó instalada…");

                String appInfoPath =
                        "/media/developer/apps/usr/palm/applications/"
                                + appId
                                + "/appinfo.json";

                String verifyCmd =
                        "if [ -f '" + appInfoPath + "' ]; then "
                                + "cat '" + appInfoPath + "'; "
                                + "else echo '__FENIX_NOT_INSTALLED__'; fi";

                String verifyOut = execCollect(session, verifyCmd, 12000);

                if (!verifyOut.contains("__FENIX_NOT_INSTALLED__")
                        && verifyOut.contains("\"id\"")
                        && verifyOut.contains(appId)
                        && verifyOut.contains("\"version\"")
                        && verifyOut.contains(version)) {
                    installed = true;
                }
            }

            if (!installed) {
                throw new Exception(
                        "La instalación no llegó a un estado final. "
                                + summarizeInstallState(out)
                );
            }

            step(95, "Abriendo FÉNIX TV…");

            String launchPayload = "{\"id\":\"" + appId + "\"}";
            String launchCmd =
                    "/usr/bin/luna-send-pub -n 1 -w 15000 " +
                    "'luna://com.webos.applicationManager/launch' " +
                    "'" + launchPayload + "'";

            String launch = execUntil(session, launchCmd, 20000);

            execUntil(
                    session,
                    "rm -f '" + remote + "'",
                    8000
            );

            if (launch.contains("\"returnValue\":true")) {
                success("✅ FÉNIX TV " + version + " instalada y abierta correctamente.");
            } else {
                success(
                        "✅ FÉNIX TV " + version +
                        " quedó instalada. Ábrela desde el launcher de la LG."
                );
            }

        } catch (Exception e) {
            fail("❌ " + (
                    e.getMessage() == null
                            ? e.getClass().getSimpleName()
                            : e.getMessage()
            ));
        } finally {
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
            if (ipk != null && ipk.exists()) {
                ipk.delete();
            }
        }
    }

    private void step(int p, String msg) {
        runOnUiThread(() -> {
            progress.setProgress(p);
            status.setText(msg);
            status.setTextColor(Color.rgb(203, 211, 227));
        });
    }

    private void success(String msg) {
        runOnUiThread(() -> {
            progress.setProgress(100);
            status.setText(msg);
            status.setTextColor(Color.rgb(140, 233, 154));
            installButton.setEnabled(true);
        });
    }

    private void fail(String msg) {
        runOnUiThread(() -> {
            progress.setProgress(0);
            status.setText(msg);
            status.setTextColor(Color.rgb(255, 135, 135));
            installButton.setEnabled(true);
        });
    }

    private void setStatus(String msg, boolean ok) {
        status.setText(msg);
        status.setTextColor(
                ok ? Color.rgb(140, 233, 154) : Color.rgb(203, 211, 227)
        );
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackgroundColor(Color.rgb(17, 22, 36));

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cp.topMargin = dp(10);
        card.setLayoutParams(cp);
        return card;
    }

    private TextView label(String s) {
        TextView t = text(s, 13, Color.rgb(174, 184, 206), false);
        t.setPadding(0, dp(14), 0, dp(6));
        return t;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(110, 122, 148));
        e.setTextColor(Color.WHITE);
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackgroundColor(Color.rgb(11, 16, 26));
        e.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(54)
        ));
        return e;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private static String readText(URL url, int timeout) throws Exception {
        return new String(readBytes(url, timeout), StandardCharsets.UTF_8);
    }

    private static byte[] readBytes(URL url, int timeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "FenixBridge/1.1");

        int code = c.getResponseCode();
        if (code < 200 || code >= 300) {
            throw new Exception("HTTP " + code + " al conectar con " + url.getHost());
        }

        try (
                InputStream in = c.getInputStream();
                ByteArrayOutputStream out = new ByteArrayOutputStream()
        ) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static void downloadTo(URL url, File out, int timeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(timeout);
        c.setReadTimeout(timeout);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "FenixBridge/1.1");

        int code = c.getResponseCode();
        if (code < 200 || code >= 300) {
            throw new Exception("No se pudo descargar el IPK (HTTP " + code + ").");
        }

        try (
                InputStream in = c.getInputStream();
                java.io.FileOutputStream fos = new java.io.FileOutputStream(out)
        ) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) {
                fos.write(buf, 0, n);
            }
        } finally {
            c.disconnect();
        }
    }

    private static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");

        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) {
                md.update(buf, 0, n);
            }
        }

        StringBuilder sb = new StringBuilder();
        for (byte b : md.digest()) {
            sb.append(String.format("%02x", b));
        }

        return sb.toString();
    }

    private static String execCollect(
            Session session,
            String command,
            long timeoutMs
    ) throws Exception {
        ChannelExec ch = (ChannelExec) session.openChannel("exec");
        ch.setCommand(command);
        ch.setInputStream(null);

        ByteArrayOutputStream err = new ByteArrayOutputStream();
        ch.setErrStream(err);

        InputStream in = ch.getInputStream();
        ch.connect(10000);

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        long deadline = System.currentTimeMillis() + timeoutMs;

        while (System.currentTimeMillis() < deadline) {
            boolean readSomething = false;

            while (in.available() > 0) {
                int n = in.read(buf, 0, Math.min(buf.length, in.available()));
                if (n < 0) break;
                out.write(buf, 0, n);
                readSomething = true;

                String s = out.toString(StandardCharsets.UTF_8.name());

                if (s.contains("\"statusValue\":30")
                        || s.contains("\"statusValue\": 30")
                        || s.contains("\"state\":\"installed\"")
                        || s.contains("\"statusValue\":24")
                        || s.contains("\"statusValue\": 24")
                        || s.contains("\"returnValue\":false")) {
                    if (ch.isConnected()) ch.disconnect();
                    String stderr = err.toString(StandardCharsets.UTF_8.name());
                    return s + (stderr.isEmpty() ? "" : "\\n" + stderr);
                }
            }

            if (ch.isClosed()) {
                while (in.available() > 0) {
                    int n = in.read(buf, 0, Math.min(buf.length, in.available()));
                    if (n < 0) break;
                    out.write(buf, 0, n);
                }
                break;
            }

            if (!readSomething) Thread.sleep(120);
        }

        if (ch.isConnected()) ch.disconnect();

        String stdout = out.toString(StandardCharsets.UTF_8.name());
        String stderr = err.toString(StandardCharsets.UTF_8.name());
        return stdout + (stderr.isEmpty() ? "" : "\\n" + stderr);
    }

    private static String execUntil(
            Session session,
            String command,
            long timeoutMs
    ) throws Exception {
        return execCollect(session, command, timeoutMs);
    }

    private static String summarizeInstallState(String s) {
        if (s == null || s.isEmpty()) return "Sin respuesta del instalador de webOS.";

        String statusValue = "";
        java.util.regex.Matcher sm = java.util.regex.Pattern
                .compile("\"statusValue\"\\s*:\\s*(\\d+)")
                .matcher(s);
        while (sm.find()) statusValue = sm.group(1);

        String reason = "";
        java.util.regex.Matcher rm = java.util.regex.Pattern
                .compile("\"reason\"\\s*:\\s*\"([^\"]*)\"")
                .matcher(s);
        while (rm.find()) reason = rm.group(1);

        if (!statusValue.isEmpty()) {
            String label;
            switch (statusValue) {
                case "268": label = "Verificando el IPK (268)."; break;
                case "269": label = "Solicitando verificación del IPK (269)."; break;
                case "270": label = "Verificación del IPK completada (270)."; break;
                case "271": label = "Verificación adicional requerida (271)."; break;
                case "272": label = "Verificación adicional solicitada (272)."; break;
                case "273": label = "Verificación adicional completada (273)."; break;
                case "30": label = "Instalación completada correctamente (30)."; break;
                case "24": label = "Error instalando el IPK (24)."; break;
                default: label = "Estado de instalación " + statusValue + "."; break;
            }
            return label + (reason.isEmpty() ? "" : " " + reason);
        }

        return trimForUser(s);
    }

    private static boolean isPrivateIpv4(String ip) {
        if (ip == null || !ip.matches("\\d{1,3}(\\.\\d{1,3}){3}")) {
            return false;
        }

        String[] p = ip.split("\\.");
        int[] n = new int[4];

        try {
            for (int i = 0; i < 4; i++) {
                n[i] = Integer.parseInt(p[i]);
                if (n[i] < 0 || n[i] > 255) return false;
            }
        } catch (Exception e) {
            return false;
        }

        return n[0] == 10
                || (n[0] == 192 && n[1] == 168)
                || (n[0] == 172 && n[1] >= 16 && n[1] <= 31);
    }

    private static String safeFile(String s) throws Exception {
        if (s == null || !s.matches("[A-Za-z0-9._-]+\\.ipk")) {
            throw new Exception("Nombre de IPK inválido.");
        }
        return s;
    }

    private static String safeAppId(String s) throws Exception {
        if (s == null || !s.matches("[A-Za-z0-9._-]+")) {
            throw new Exception("App ID inválido.");
        }
        return s;
    }

    private static String trimForUser(String s) {
        if (s == null) return "";
        s = s.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 220 ? s.substring(0, 220) + "…" : s;
    }
}
