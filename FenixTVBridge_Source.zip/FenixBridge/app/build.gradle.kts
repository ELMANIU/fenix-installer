plugins {
    id("com.android.application")
}

android {
    namespace = "com.fenixtv.bridge"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.fenixtv.bridge"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "1.0.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.github.mwiede:jsch:2.28.7")
}
